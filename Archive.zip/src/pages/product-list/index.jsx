import React from 'react';
import { Row, Col, Button, Typography, Space, Skeleton } from 'antd';
import ProductItem from './ProductItem';
import axios from 'axios';

export default function ProductList() {
  const [products, setProducts] = React.useState([]);
  const [isLoading, setIsLoading] = React.useState(false);
  // const handleFetchProducts = () => {
  //   setIsLoading(true);
  //   axios
  //     .get('https://apistore.cybersoft.edu.vn/api/Product')
  //     .then((response) => {
  //       const data = response.data.content;
  //       setProducts(data);
  //     })
  //     .catch((error) => {
  //       console.log('Lỗi kết nối đến API', error);
  //       alert('Lỗi kết nối đến API');
  //     })
  //     .finally(() => {
  //       console.log('Kết thúc gọi API');
  //       setIsLoading(false);
  //     });
  // };

  const handleFetchProducts = async () => {
    setIsLoading(true);
    try {
      const response = await axios.get('https://apistore.cybersoft.edu.vn/api/Product');
      const data = response.data.content;
      setProducts(data);
    } catch (error) {
      console.log('Lỗi kết nối đến API', error);
      alert('Lỗi kết nối đến API');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Row gutter={[24, 24]}>
      <Col span={24}>
        <Button type='primary' size='large' onClick={handleFetchProducts} loading={isLoading} disabled={isLoading}>
          Lấy danh sách sản phẩm
        </Button>
      </Col>
      {/* <Col span={4}>
        <ProductItem
          product={{
            name: 'Product 1',
            price: '$200',
            image: 'https://via.placeholder.com/150',
          }}
        />
      </Col> */}

      {isLoading && (
        <>
          {Array.from({ length: 8 }).map((_, index) => (
            <Col span={8} key={index}>
              <Skeleton.Node active={true} style={{ width: 650, height: 450 }} />
            </Col>
          ))}
        </>
      )}
      {!isLoading &&
        products.map((item) => {
          // item : { id: 1, name: 'Product 1', price: '$200', image: 'https://via.placeholder.com/150', ... }
          return (
            <Col span={8} key={item.id}>
              <ProductItem product={item} />
            </Col>
          );
        })}
    </Row>
  );
}
