import React from "react";
import Header from "../../components/Header";

const HomePage = () => {
  return <div>hello homepage</div>;
};

export default HomePage;
