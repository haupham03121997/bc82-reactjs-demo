import React from 'react';

export default function Footer() {
  return (
    <footer>
      <div>Footer</div>
    </footer>
  );
}
