import React from "react";

export default function Header() {
  return (
    <header>
      <ul>
        <li>Trang chủ </li>
        <li>Sản phẩm</li>
        <li>Liên hệ</li>
      </ul>
    </header>
  );
}
